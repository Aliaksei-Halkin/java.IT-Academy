package edu.academy.visibility;

public class Prot {
    private int hairLengthPrivate;
    protected int hairLengthProtected;
    int hairLengthDefault;
    public int hairLengthPublic;
}
