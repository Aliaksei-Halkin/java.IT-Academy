package edu.academy.visibility;

public class ProtMain {
    public static void main(String[] args) {
        Prot a = new Prot();
//        a.hairLengthPrivate = 10;
        a.hairLengthDefault = 10;
        a.hairLengthProtected = 10;
        a.hairLengthPublic = 10;

    }
}
