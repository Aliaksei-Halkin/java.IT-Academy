package edu.academy;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("byte min " + Byte.MIN_VALUE + " max " + Byte.MAX_VALUE);
        byte b = 127; // -128...127
        Byte bR = Byte.MIN_VALUE; //-128...127

        long l = 0;
        Long lR = 0L;

        float f = 8.0f;
        Float fR = .1F;

        double d = .0;
        Double dR = .0D;

        //0l 0L
        //0f 0F .1F
        //0d 0D .1D

         int a;
        Integer c;

//        a = a + 1;
//
//        System.out.println(a);
//        System.out.println(c);

//        short
//        char
//        int
//        long
//        float
//        double
//        boolean
    }
}
