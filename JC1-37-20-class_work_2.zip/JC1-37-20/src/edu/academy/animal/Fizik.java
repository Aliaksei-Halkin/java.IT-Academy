package edu.academy.animal;

public class Fizik extends Animal {
    public void eat(int number){
        System.out.println("Всё во имя науки");
    }
}
