package com.company;

public interface ISearchEngine {

    public int search(String text, String word);


}
