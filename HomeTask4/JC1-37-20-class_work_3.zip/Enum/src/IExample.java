public interface IExample {
    public void Area(int area);

    public default void Population(int population) {

    }
}
