public interface IExample {

    public int getArea();

    public int getPopulation();
}

