package com.company;

import static java.lang.Math.*;

public class CalculatorWithOperator {
    //сделал все
    public static double sum(double a, double b) {
        return (a + b);
    }

    public static double minus(double a, double b) {
        return (a - b);
    }

    public static double devide(double a, double b) {
        return (a / b);
    }

    public static double multiply(double a, double b) {
        return (a / b);
    }

    public static double stepen(double c, double d) {
        return (pow(c,d));

    }

    public static double modul(double e) {
        return (abs(e));
    }

    public static double sqrt(double f) {
        return (sqrt(f));
    }

}



